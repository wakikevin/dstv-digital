<?php

//define server parameters

define("BASE_URL", "http://getdstv.co.ke");
define('DATABASE_SERVER','localhost');
define('DATABASE_USER','getdstvc_admin');
define('DATABASE_PASSWORD','Di9C4Ge7c3@');
define('DATABASE_NAME','getdstvc_leads');
define('DBPREFIX','dstv_');

define('CONNECTION_STRING', 'mysql:host=localhost;dbname=getdstvc_leads');


//define email parameters

define('EMAIL_SERVER','localhost');
define('EMAIL_FROM_ADDRESS', 'kevinwaki@gmail.com');
define('EMAIL_FROM_NAME', 'DSTV Leads');
define('EMAIL_REPLY_TO_ADDRESS', 'kevinwaki@gmail.com');
define('EMAIL_REPLY_TO_NAME', 'DSTV Leads');
define('EMAIL_SUBJECT', 'DSTV Leads');
define('EMAIL_ALTERNATE_BODY_MESSAGE', 'If you are aunable to see this email, contact the administrator.');



?>